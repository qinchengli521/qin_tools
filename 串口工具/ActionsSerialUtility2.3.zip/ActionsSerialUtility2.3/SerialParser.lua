print("\nSerialParser: Actions Log Frame (Thu, Aug 25, 2022  4:45:25 PM)")


-- String table
ALF_ModuleStrTable = {}
ALF_FormatStrTable = {}

function ALF_LoadStrTable(str_table, file_name, prefix)
    --
    f = io.open(file_name, "rb")
    
    if (f ~= nil)
    then
        i = 0
        
        for s in f:lines()
        do
            s = string.match(s, "%s*"..prefix..".+\"(.*)\"%s*$")
            
            if (s ~= nil)
            then
                str_table[i] = s
                i = i + 1
            end
        end
        
        print(file_name..": "..i)
        f:close()
    end
end

-- Load string table
ALF_LoadStrTable(ALF_ModuleStrTable, "log_model_id.h", "ALF_MODEL_")
ALF_LoadStrTable(ALF_FormatStrTable, "log_str_id.h",   "ALF_STR_")

function ALF_StringLevel(level)
    --
    if (level < 1) then level = 1 end
    if (level > 4) then level = 4 end
    
    s = { "<E>", "<W>", "<I>", "<D>" }
    return s[level]
end

function ALF_StringMoudle(module_id)
    --
    s = ALF_ModuleStrTable[module_id]
    
    if (s == nil)
    then
        s = string.format("MODULE_ID_%d", module_id)
    end
    
    return s
end

function ALF_StringFormat(vtype, value)
    --
    -- alf_print_str
    if (vtype == 0x00)
    then
        return value
    end
    
    -- alf_print_id
    if (vtype == 0x01)
    then
        n = #value
        
        if (n < 4) or ((n % 4) ~= 0)
        then
            return "..."
        end
        
        str_id_h = string.unpack(">H", value, 1)
        str_id_l = string.unpack(">H", value, 3)
        
        fmt_str = ALF_FormatStrTable[str_id_l]
        
        if (fmt_str == nil)
        then
            fmt_str = string.format("STR_ID_%d", str_id_l)
        end
        
        num_args = (n // 4) - 1
        a = {}
        
        for i = 1, num_args, 1
        do
            a[i] = string.unpack(">I", value, 1 + i*4)
        end
        
        s = string.format(fmt_str, 
            a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9])
        
        return s
    end
    
    return "..."
end

-- Return used data length and string genereted.
--
function SerialParser(rx_data)
    --
    tag = "\x10";
    
    -- Find ALF tag
    i, j = string.find(rx_data, tag, 1, true)
    
    -- plain chars?
    if (i == nil)
    then
        return #rx_data, rx_data
    end
    
    -- Return plain chars before ALF tag
    if (i > 1)
    then
        s = string.sub(rx_data, 1, i-1)
        return #s, s
    end
    
    -- Wait ALF header, 2 bytes (tag + version)
    if (#rx_data < 2)
    then
        return 0, nil
    end
    
    -- check version
    if (string.byte(rx_data, 2) ~= 0x01)
    then
        s = string.sub(rx_data, 1, 2)
        return #s, s
    end
    
    -- wait ALF header, 18 bytes
    if (#rx_data < 18)
    then
        return 0, nil
    end
    
    -- Length of data followed
    n = string.byte(rx_data, 3)
    
    -- Wait whole ALF data
    if (#rx_data < 18 + n)
    then
        return 0, nil
    end
    
    -- Parse ALF header
    seq, ts, level, module_id, line, vtype, chksum =
        string.unpack(">IIBHHBB", rx_data, 4)
    
    -- Parse ALF data
    s = string.format("[%d.%03d] %s [%s]@[%d]", 
        ts // 1000, ts % 1000,
        ALF_StringLevel(level), 
        ALF_StringMoudle(module_id), 
        line)
    
    if (n ~= 0)
    then
        value = string.sub(rx_data, 19, 18 + n)
        s = s.." "..ALF_StringFormat(vtype, value)
    end
    
    return (18 + n), s.."\n"
end
